const exp=require("express");
const addRouter=exp.Router();

function router(nav)
{
    addRouter.route('/')
    .get((req,res)=>{
        res.render('add',{nav,title:"New Book"})
    })
    return addRouter
}
module.exports=router;